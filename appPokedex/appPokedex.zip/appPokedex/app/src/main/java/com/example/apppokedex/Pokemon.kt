package com.example.apppokedex

data class Pokemon(
    val num_pokedex: Int,
    val imagen_pokemon: Int,
    val nombrePokemon: String,
    val tipo_1: String,
    val tipo_2: String
)