package com.example.apppokedex

class Item {

}