package com.example.apppokedex

class PokemonProvider {
    companion object {
        val pokemonList: List<Pokemon> = listOf(
        )
    }
}

